
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message } from "../types";

const SYSTEM_INSTRUCTION = `
أنت "مايكي" (Maiki)، المساعد التعليمي الذكي لمدارس سما العراق الأهلية.
مهمتك: مساعدة الطلاب في المنهج العراقي وتزويدهم بالروابط التعليمية.

قواعد الروابط (Strict Linking Rules):
1. استخدم دائماً صيغة Markdown للروابط لتظهر بشكل احترافي: [اسم الموقع أو الملف](رابط الموقع الكامل).
2. مثال: بدلاً من كتابة moedu.gov.iq، اكتب [موقع وزارة التربية العراقية](https://moedu.gov.iq).
3. تأكد دائماً من أن الرابط يبدأ بـ https:// أو http://.
4. الروابط المسموحة: مواقع وزارة التربية، منصة نيوتن، موقع المدرسة samairaqonline.tk، ونتائج الامتحانات الرسمية.

قدراتك:
- حل الأسئلة وتوليد صور تعليمية توضيحية.
- تقديم روابط مباشرة للكتب المنهجية (PDF) إذا طلب الطالب ذلك.
- التحدث بلهجة عراقية مهذبة ومشجعة.
`;

export const getMaikiResponse = async (history: Message[], currentPrompt: string, imageBase64?: string): Promise<{ text: string; image?: string }> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const contents = history.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [
        { text: msg.text },
        ...(msg.image ? [{
          inlineData: {
            mimeType: "image/jpeg",
            data: msg.image.includes(',') ? msg.image.split(',')[1] : msg.image
          }
        }] : [])
      ]
    }));

    const currentParts: any[] = [];
    if (imageBase64) {
      currentParts.push({
        inlineData: {
          mimeType: "image/jpeg",
          data: imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64
        },
      });
    }
    currentParts.push({ text: currentPrompt || "مرحباً مايكي" });
    
    contents.push({ role: 'user', parts: currentParts });

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.6,
      },
    });

    let textOutput = "";
    let imageOutput: string | undefined = undefined;

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.text) textOutput += part.text;
        else if (part.inlineData) imageOutput = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }

    return { text: textOutput, image: imageOutput };
  } catch (error) {
    console.error("Maiki Error:", error);
    return { text: "عذراً، واجهت مشكلة في الاتصال. حاول مرة أخرى." };
  }
};
