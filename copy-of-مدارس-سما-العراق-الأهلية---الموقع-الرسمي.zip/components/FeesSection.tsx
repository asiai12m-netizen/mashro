
import React from 'react';
import { Check, HelpCircle } from 'lucide-react';
import { FeeItem } from '../types';

const FeesSection: React.FC = () => {
  const fees: FeeItem[] = [
    {
      stage: "المرحلة الابتدائية (1-6)",
      price: "1,800,000 د.ع",
      details: "تعليم لغات مكثف + مختبرات ذكاء"
    },
    {
      stage: "المرحلة المتوسطة (1-3)",
      price: "2,200,000 د.ع",
      details: "تركيز على المواد العلمية والتحضير الوزاري"
    },
    {
      stage: "المرحلة الإعدادية (4-6)",
      price: "2,800,000 د.ع",
      details: "إشراف نخبة المدرسين ومتابعة أكاديمية مستمرة"
    }
  ];

  return (
    <section className="py-24 bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="space-y-4">
            <h3 className="text-primary font-bold text-lg uppercase tracking-wider">الاستثمار في المستقبل</h3>
            <h2 className="text-3xl md:text-5xl font-black text-white">اسعار الاقساط للمراحل الأتية</h2>
          </div>
          <p className="text-slate-400 max-w-md font-medium">
            نقدم تسهيلات في الدفع وأقساطاً مريحة تراعي وضع العائلة العراقية الكريمة، مع خصومات للأخوة والمتفوقين.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fees.map((fee, idx) => (
            <div key={idx} className="bg-slate-800 p-8 rounded-[32px] shadow-xl border border-slate-700 hover:shadow-primary/10 hover:border-primary/50 transition-all flex flex-col group">
              <h4 className="text-lg font-bold text-slate-500 mb-2 uppercase tracking-tight group-hover:text-secondary transition-colors">{fee.stage}</h4>
              <div className="text-3xl font-black text-primary mb-6">{fee.price}</div>
              <ul className="space-y-4 mb-8 flex-grow">
                <li className="flex items-start gap-3 text-sm text-slate-300 leading-relaxed">
                  <Check className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                  <span>{fee.details}</span>
                </li>
                <li className="flex items-start gap-3 text-sm text-slate-300 leading-relaxed">
                  <Check className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                  <span>دخول كافة المختبرات العلمية</span>
                </li>
              </ul>
              <button className="w-full py-4 rounded-2xl bg-slate-900 text-white font-bold hover:bg-primary transition-all border border-slate-700 group-hover:border-transparent">
                حجز مقعد الآن
              </button>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-slate-800/40 rounded-3xl p-6 border border-dashed border-slate-700 flex items-center gap-4 text-slate-400">
          <HelpCircle className="w-6 h-6 text-primary" />
          <p className="text-sm font-medium">ملاحظة: الأسعار قابلة للتعديل حسب الموسم الدراسي والمنح المتوفرة. يرجى مراجعة الإدارة للتفاصيل النهائية.</p>
        </div>
      </div>
    </section>
  );
};

export default FeesSection;
