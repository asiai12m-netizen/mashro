
import React from 'react';
import { UserCheck, Cpu, BookOpen } from 'lucide-react';

const WhyUsSection: React.FC = () => {
  const features = [
    {
      title: "كادر تدريسي نخبوي",
      desc: "نفتخر بامتلاكنا كادراً تدريسياً من حملة الشهادات العليا والخبرات الطويلة، المختارين بعناية لضمان وصول المعلومة بأفضل الطرق التربوية الحديثة.",
      icon: <UserCheck className="w-8 h-8 text-primary" />
    },
    {
      title: "نظام تعليمي متطور",
      desc: "نعتمد نظاماً تعليمياً يركز على الفهم والاستنباط بدلاً من التلقين، مدمجاً بآخر الوسائل التعليمية الرقمية والمختبرات المجهزة بالكامل.",
      icon: <Cpu className="w-8 h-8 text-primary" />
    },
    {
      title: "بيئة تربوية محفزة",
      desc: "بيئتنا المدرسية مصممة لتكون منبعاً للإبداع، حيث نوفر مساحات للأنشطة اللاصفية والرياضية التي تنمي شخصية الطالب وتصقل مواهبه.",
      icon: <BookOpen className="w-8 h-8 text-primary" />
    }
  ];

  return (
    <section className="py-24 bg-dark relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 space-y-4">
          <h3 className="text-primary font-bold text-lg tracking-widest uppercase">لماذا نحن؟</h3>
          <h2 className="text-3xl md:text-5xl font-black text-white">لماذا عليك التسجيل في مدارس سما العراق؟</h2>
          <div className="w-24 h-1.5 bg-secondary mx-auto rounded-full"></div>
        </div>

        <div className="mb-16 bg-slate-800/50 backdrop-blur-sm p-8 md:p-12 rounded-[40px] border border-slate-700 shadow-2xl">
          <p className="text-xl md:text-2xl text-slate-200 leading-relaxed text-center font-medium italic">
            "تعتبر مدارس سما العراق الأهلية صرحاً تعليمياً متميزاً، حيث نجمع بين الرصانة العلمية والروح الأبوية. كادرنا ليس مجرد مدرسين، بل هم قادة وموجهون يبنون أجيالاً. نحن في سما العراق لا ندرس المناهج فحسب، بل نبني الشخصيات ونغرس القيم التي تمكن طلابنا من التفوق في كل مجالات الحياة."
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <div key={i} className="group p-8 bg-slate-800 hover:bg-primary transition-all duration-500 hover:-translate-y-2 border border-slate-700 rounded-3xl shadow-lg">
              <div className="bg-slate-900 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-sm group-hover:bg-white/20 transition-colors">
                {f.icon}
              </div>
              <h4 className="text-2xl font-bold mb-4 text-white group-hover:text-white transition-colors">{f.title}</h4>
              <p className="text-slate-400 leading-relaxed group-hover:text-blue-50 transition-colors">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyUsSection;
