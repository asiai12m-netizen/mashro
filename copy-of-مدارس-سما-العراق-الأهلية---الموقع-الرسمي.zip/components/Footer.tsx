
import React from 'react';
import { Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 text-center space-y-4">
        <p className="text-slate-200 font-bold text-lg">
          جميع الحقوق محفوظة &copy; {new Date().getFullYear()} مدارس سما العراق الأهلية
        </p>
        <p className="text-slate-500 text-sm flex items-center justify-center gap-2">
          تم التصميم والتطوير بكل 
          <Heart className="w-4 h-4 text-red-500 fill-current" />
          لدعم مستقبل طلابنا
        </p>
        <p className="text-primary font-black text-sm tracking-[0.2em] uppercase">SAMAIRAQONLINE.TK</p>
      </div>
    </footer>
  );
};

export default Footer;
