
import React from 'react';
import { ArrowLeft, ShieldCheck, Users } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-24 pb-24 md:pt-32 md:pb-32 bg-dark">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -z-10 w-full h-full bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in-right">
            <div className="inline-flex items-center gap-2 bg-slate-800 text-secondary px-4 py-1.5 rounded-full text-sm font-bold border border-slate-700">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-secondary"></span>
              </span>
              فتح باب التسجيل للعام الدراسي الجديد
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black text-white leading-tight">
              نصنع المستقبل في <br />
              <span className="text-primary italic drop-shadow-sm">مدارس سما العراق</span>
            </h2>
            
            <p className="text-lg text-slate-400 leading-relaxed max-w-lg">
              نهدف إلى تقديم تعليم نوعي يدمج بين القيم العربية الأصيلة وأحدث التقنيات العالمية، لتنشئة جيل قادر على مواجهة تحديات المستقبل.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button className="bg-primary text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-primary/30 flex items-center gap-2 hover:bg-accent transition-all group">
                سجل الآن
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              </button>
              <button className="bg-slate-800 text-white border-2 border-slate-700 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-700 transition-all">
                تعرف علينا
              </button>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-4">
              <div className="flex flex-col gap-1">
                <span className="text-2xl font-bold text-primary">15+</span>
                <span className="text-xs text-slate-500 font-bold uppercase">سنة خبرة</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-2xl font-bold text-primary">500+</span>
                <span className="text-xs text-slate-500 font-bold uppercase">طالب وطالبة</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-2xl font-bold text-primary">40+</span>
                <span className="text-xs text-slate-500 font-bold uppercase">كادر متميز</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-[40px] overflow-hidden shadow-2xl border-8 border-slate-800 ring-1 ring-slate-700">
              <img 
                src="https://images.unsplash.com/photo-1577896851231-70ef18881754?q=80&w=2070&auto=format&fit=crop" 
                alt="معلم وطلاب في بيئة تعليمية رصينة" 
                className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700 brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark/60 via-transparent to-transparent"></div>
            </div>
            
            {/* Floating Badges */}
            <div className="absolute -top-6 -right-6 bg-slate-800 p-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700">
              <div className="bg-yellow-500/20 p-2 rounded-lg">
                <ShieldCheck className="text-yellow-500 w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400">نظام معتمد</p>
                <p className="text-sm font-bold text-white">وزارة التربية</p>
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 bg-slate-800 p-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700">
              <div className="bg-emerald-500/20 p-2 rounded-lg">
                <Users className="text-emerald-500 w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400">بيئة آمنة</p>
                <p className="text-sm font-bold text-white">100% رعاية</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
