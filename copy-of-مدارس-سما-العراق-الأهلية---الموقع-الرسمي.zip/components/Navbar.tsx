
import React, { useState } from 'react';
import { Bot, GraduationCap, Share2, Check } from 'lucide-react';

interface NavbarProps {
  onOpenChat: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onOpenChat }) => {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const siteUrl = window.location.origin;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(siteUrl);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = siteUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('فشل النسخ:', err);
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-dark/90 backdrop-blur-xl shadow-2xl border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          <div className="flex items-center gap-2 order-1">
            <button 
              onClick={onOpenChat}
              className="flex items-center gap-2 bg-primary hover:bg-accent text-white px-3 md:px-5 py-2.5 rounded-xl font-bold shadow-lg transition-all group border border-white/10"
            >
              <Bot className="w-5 h-5 group-hover:rotate-12 transition-transform text-secondary" />
              <span className="text-xs md:text-sm">مايكي الذكي</span>
            </button>
          </div>

          <div className="flex items-center gap-4 md:gap-8 order-2">
            <div className="hidden lg:flex items-center gap-6">
              <a href="#why-us" className="text-slate-300 hover:text-secondary font-bold transition-colors">لماذا نحن؟</a>
              <a href="#fees" className="text-slate-300 hover:text-secondary font-bold transition-colors">الأقساط</a>
              <a href="#contact" className="text-slate-300 hover:text-secondary font-bold transition-colors">اتصل بنا</a>
            </div>
            
            <div className="flex items-center gap-3 border-r border-slate-700 pr-4">
              <div className="text-right hidden sm:block">
                <h1 className="text-sm md:text-lg font-black text-white leading-none">مدارس سما العراق</h1>
                <p className="text-[9px] text-secondary font-bold tracking-tighter uppercase">الموقع الرسمي</p>
              </div>
              <div className="bg-gradient-to-br from-primary to-blue-700 p-2 rounded-xl">
                <GraduationCap className="text-white w-6 h-6 md:w-7 md:h-7" />
              </div>
            </div>
          </div>

          <div className="order-3 flex gap-2">
            <button 
              onClick={handleShare}
              className={`p-2.5 rounded-xl transition-all border ${
                copied 
                ? 'bg-emerald-500 text-white border-emerald-400' 
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              } shadow-lg`}
              title="نسخ رابط الموقع"
            >
              {copied ? <Check className="w-5 h-5" /> : <Share2 className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>
    </nav>
  );
};

export default Navbar;
