
import React from 'react';
import { Phone, MapPin, Facebook, Instagram, Send } from 'lucide-react';

const ContactSection: React.FC = () => {
  return (
    <section className="py-24 bg-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-primary/90 backdrop-blur-sm rounded-[50px] overflow-hidden shadow-2xl relative min-h-[500px] flex items-center justify-center border border-white/10">
          {/* Patterns */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl -ml-48 -mb-48"></div>

          <div className="relative z-10 w-full max-w-4xl p-12 md:p-20 text-center">
            <div className="space-y-6 mb-16">
              <h2 className="text-4xl md:text-6xl font-black text-white">التواصل مع قسم التسجيل</h2>
              <div className="w-24 h-2 bg-secondary mx-auto rounded-full shadow-lg"></div>
              <p className="text-blue-100 text-xl max-w-2xl mx-auto opacity-90">يسرنا استقبالكم والإجابة على استفساراتكم حول التسجيل والانضمام لعائلة مدارس سما العراق.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center justify-center">
              {/* Phone Info */}
              <div className="flex flex-col items-center gap-4 group">
                <div className="w-20 h-20 rounded-[30px] bg-white/10 flex items-center justify-center group-hover:bg-white/20 transition-all transform group-hover:scale-110 shadow-lg">
                  <Phone className="w-10 h-10 text-white" />
                </div>
                <div>
                  <p className="text-blue-200 text-sm font-bold uppercase tracking-widest mb-1 opacity-70">هاتف قسم التسجيل</p>
                  <p className="text-3xl font-black text-white font-mono">07810000357</p>
                </div>
              </div>

              {/* Address Info */}
              <div className="flex flex-col items-center gap-4 group">
                <div className="w-20 h-20 rounded-[30px] bg-white/10 flex items-center justify-center group-hover:bg-white/20 transition-all transform group-hover:scale-110 shadow-lg">
                  <MapPin className="w-10 h-10 text-white" />
                </div>
                <div>
                  <p className="text-blue-200 text-sm font-bold uppercase tracking-widest mb-1 opacity-70">موقعنا الجغرافي</p>
                  <p className="text-2xl font-bold text-white leading-tight">
                    النجف الاشرف - حي الامير <br />
                    شارع عطية الجبوري
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-center gap-6 pt-16">
              <a 
                href="https://www.facebook.com/profile.php?id=61551824451124&mibextid=LQQJ4d" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center hover:bg-secondary hover:text-primary transition-all transform hover:-translate-y-2 text-white shadow-xl border border-white/5"
                title="فيسبوك"
              >
                <Facebook className="w-7 h-7" />
              </a>
              <a 
                href="https://www.instagram.com/sama_al_iraq2?igsh=MXU2MXN0OG9kcWFheQ==" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center hover:bg-secondary hover:text-primary transition-all transform hover:-translate-y-2 text-white shadow-xl border border-white/5"
                title="انستقرام"
              >
                <Instagram className="w-7 h-7" />
              </a>
              <a 
                href="https://t.me/sama_iq_alameer" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center hover:bg-secondary hover:text-primary transition-all transform hover:-translate-y-2 text-white shadow-xl border border-white/5"
                title="تلغرام"
              >
                <Send className="w-7 h-7" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
