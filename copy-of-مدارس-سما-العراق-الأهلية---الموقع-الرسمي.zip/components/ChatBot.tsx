
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User, Loader2, Camera, RefreshCcw, ExternalLink, Link as LinkIcon } from 'lucide-react';
import { Message } from '../types';
import { getMaikiResponse } from '../services/geminiService';

interface ChatBotProps {
  onClose: () => void;
}

const STORAGE_KEY = 'maiki_chat_history_v1';

const ChatBot: React.FC<ChatBotProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return []; }
    }
    return [{
      role: 'model',
      text: "أهلاً بك في مدارس سما العراق! أنا مايكي، مساعدك الدراسي. اطلب مني روابط الكتب أو المناهج وسأزودك بها فوراً."
    }];
  });

  const [input, setInput] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  // دالة متطورة لتحويل النص والروابط إلى HTML
  const renderMessageContent = (text: string) => {
    // 1. التعرف على صيغة Markdown [Title](URL)
    const markdownRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    // 2. التعرف على الروابط العادية
    const urlRegex = /(?<!\()https?:\/\/[^\s]+/g;

    let content = text;
    const linksFound: { title: string, url: string }[] = [];

    // استخراج روابط الماركدوان أولاً
    content = content.replace(markdownRegex, (match, title, url) => {
      linksFound.push({ title, url });
      return ""; // سنعرضها كأزرار في الأسفل
    });

    // استخراج الروابط العادية المتبقية
    content = content.replace(urlRegex, (url) => {
      linksFound.push({ title: "زيارة الرابط", url });
      return "";
    });

    return (
      <div className="space-y-3">
        <p className="whitespace-pre-wrap leading-relaxed">{content.trim()}</p>
        {linksFound.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
            {linksFound.map((link, idx) => (
              <a
                key={idx}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-secondary/20 hover:bg-secondary/40 text-secondary px-4 py-2 rounded-xl text-sm font-bold border border-secondary/30 transition-all transform hover:scale-105"
              >
                <LinkIcon className="w-4 h-4" />
                {link.title}
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
            ))}
          </div>
        )}
      </div>
    );
  };

  const clearHistory = () => {
    if (window.confirm("هل تريد مسح سجل المحادثة؟")) {
      setMessages([{ role: 'model', text: "تم المسح! كيف يمكنني مساعدتك الآن؟" }]);
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedImage) || isLoading) return;
    const userText = input.trim();
    const userImg = selectedImage || undefined;
    
    setInput('');
    setSelectedImage(null);
    setMessages(prev => [...prev, { role: 'user', text: userText, image: userImg }]);
    setIsLoading(true);

    try {
      const result = await getMaikiResponse(messages, userText, userImg);
      setMessages(prev => [...prev, { role: 'model', text: result.text, image: result.image }]);
    } catch {
      setMessages(prev => [...prev, { role: 'model', text: "عذراً، حدث خطأ. حاول مرة أخرى." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 md:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 w-full max-w-2xl h-[90vh] rounded-[40px] shadow-[0_0_80px_rgba(0,86,179,0.3)] overflow-hidden flex flex-col border border-slate-700">
        
        {/* Header */}
        <div className="bg-primary p-5 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-secondary/20 rounded-full flex items-center justify-center border border-secondary/30">
              <Bot className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h3 className="font-black text-lg">مايكي (Maiki)</h3>
              <p className="text-[10px] text-blue-200 uppercase font-bold tracking-widest">مساعد ذكي وروابط نشطة</p>
            </div>
          </div>
          <div className="flex gap-1">
            <button onClick={clearHistory} className="p-2 hover:bg-white/10 rounded-lg text-slate-300 transition-colors"><RefreshCcw className="w-5 h-5" /></button>
            <button onClick={onClose} className="p-2 hover:bg-red-500 rounded-lg transition-colors"><X className="w-6 h-6" /></button>
          </div>
        </div>

        {/* Chat Area */}
        <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar bg-slate-900/50">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-10 h-10 rounded-2xl flex-shrink-0 flex items-center justify-center shadow-lg ${m.role === 'user' ? 'bg-secondary text-slate-900' : 'bg-primary text-white'}`}>
                {m.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              <div className="max-w-[80%] space-y-2">
                {m.image && (
                  <div className="rounded-2xl overflow-hidden border border-slate-700 shadow-xl">
                    <img src={m.image} alt="Media" className="max-w-full h-auto" />
                  </div>
                )}
                <div className={`p-4 rounded-2xl text-sm md:text-base shadow-sm border ${
                  m.role === 'user' 
                  ? 'bg-primary text-white rounded-tr-none border-white/10' 
                  : 'bg-slate-800 text-slate-100 rounded-tl-none border-slate-700'
                }`}>
                  {renderMessageContent(m.text)}
                </div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3 animate-pulse">
              <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center"><Bot className="w-5 h-5 text-secondary" /></div>
              <div className="bg-slate-800 p-4 rounded-2xl rounded-tl-none border border-slate-700 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-primary" />
                <span className="text-xs text-slate-400 font-bold">جاري جلب الروابط والمعلومات...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-4 bg-slate-800 border-t border-slate-700">
          <div className="flex items-center gap-2 max-w-xl mx-auto">
            <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={(e) => {
               const file = e.target.files?.[0];
               if (file) {
                 const reader = new FileReader();
                 reader.onload = () => setSelectedImage(reader.result as string);
                 reader.readAsDataURL(file);
               }
            }} />
            <button onClick={() => fileInputRef.current?.click()} className={`p-3 rounded-full transition-colors ${selectedImage ? 'bg-primary text-white' : 'bg-slate-700 text-slate-400 hover:text-white'}`}>
              <Camera className="w-6 h-6" />
            </button>
            <div className="relative flex-grow">
              <input 
                type="text" value={input} 
                onChange={(e) => setInput(e.target.value)} 
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="اطلب رابطاً أو اسأل سؤالاً..."
                className="w-full bg-slate-900 border border-slate-700 rounded-full pl-12 pr-5 py-3.5 focus:outline-none focus:border-primary text-white text-sm font-bold"
              />
              <button onClick={handleSend} disabled={isLoading} className="absolute left-1.5 top-1.5 w-9 h-9 bg-primary text-white rounded-full flex items-center justify-center hover:scale-105 transition-transform">
                <Send className="w-4 h-4 -rotate-90" />
              </button>
            </div>
          </div>
          {selectedImage && (
            <div className="mt-3 flex justify-center relative">
              <img src={selectedImage} className="h-16 rounded border border-primary" alt="Preview" />
              <button onClick={() => setSelectedImage(null)} className="absolute -top-2 bg-red-500 rounded-full p-0.5 text-white"><X className="w-3 h-3"/></button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatBot;
